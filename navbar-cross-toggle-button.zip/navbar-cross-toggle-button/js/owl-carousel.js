$(document).ready(function () {
    $('.nowshowing-owl').owlCarousel({
      loop: true,
      margin: 50,
      autoplay: true,
      autoplayTimeout: 2000,
      autoplayHoverPause: true,
      nav: true,
      dots: false,
      center: true,
      items: 3,
      responsive: {
        320: {
          items: 1,
          nav: false,
		  center: true,
          
        },
        700: {
          items: 1,
		  nav: false,
		  center: false,
          
        },
        1000: {
          items: 1,
          nav: true,
		  center: false,

          
        }
      }
    })
  });